# TREDT Digital Typewriter v1.5.2.0

The supplied `tredt-boot.html` startup animation has been integrated into
the Python application as a native Tkinter animation.

The HTML source uses a 320x240 pixelated canvas, DOS boot messages,
twinkling star, fleur-de-lis sprite pieces, CRT scanlines, retro beeps,
and a 15-second timeline. The Python version reproduces those elements
inside the executable so the HTML file is NOT needed at runtime.

## Startup order

1. Windows launches `TREDT_Digital_Typewriter.exe`.
2. The editor window is hidden.
3. The 15-second TREDT Typewriter startup animation plays.
4. At 15 seconds the intro closes.
5. The main text editor appears.

## Build

Install Python 3 for Windows with Tkinter, then double-click:

`build.bat`

The resulting file is:

`dist\TREDT_Digital_Typewriter.exe`

No `TREDT.ico` is included or required.


## Dictation and Voice Monitor

Version 1.4 adds microphone dictation and a live voice-amplitude monitor.

- Click **Dictate** or press **F2** to start/stop dictation.
- Spoken words are inserted at the current text cursor.
- The bottom-right of the editor contains a **256 x 256 pixel voice monitor**.
- The monitor displays a live oscilloscope-style amplitude trace while the microphone is active.
- Speech recognition uses the SpeechRecognition Google recognizer, so an internet connection is required for transcription.
- The microphone and PyAudio packages are installed automatically by `build.bat`.

### Requirements

Windows with Python 3 and Tkinter. The build script installs:

`PyInstaller SpeechRecognition PyAudio`

If dictation cannot start after building, check Windows microphone permissions under **Settings > Privacy & security > Microphone**.

## Text formatting shortcuts

Select text and use **Ctrl+B** for bold, **Ctrl+I** for italic, **Ctrl+U** for
underline, **Ctrl++** for superscript, or **Ctrl+-** for subscript. Formatting
can be combined. Use **Ctrl+L**, **Ctrl+E**, or **Ctrl+R** to align the current
paragraph (or selected paragraphs) left, center, or right.

The editor continues to save standard `.txt` files, so these visual formatting
settings are for the current editing session and are not embedded in plain text.

## Stamps and signatures

The **Stamp** button can keep up to three image files. The **Sign** button can
keep up to seven signature images and also provides **Draw signature** for
creating one with the mouse. Choose a stored item from either button to insert
it at the text cursor. Image support is provided by Pillow and is installed by
`build.bat`.


## v1.5.2 microphone setup

Python 3.14 users do not need PyAudio. The typewriter uses `sounddevice` and `numpy`
for the live microphone amplitude monitor. SpeechRecognition remains responsible
for speech-to-text dictation.

Install:
`py -3.14 -m pip install SpeechRecognition sounddevice numpy`


## Building the Windows EXE

1. Extract the package to a normal Windows folder.
2. Double-click `build.bat`.
3. The script uses the Python launcher (`py -3.14`), installs PyInstaller,
   SpeechRecognition, sounddevice, and NumPy, removes old output, and builds
   the application.
4. On success, the executable is:
   `dist\TREDT_Digital_Typewriter.exe`

If double-clicking does not show the error, run `build.bat` from Command Prompt
so the build messages remain visible.
