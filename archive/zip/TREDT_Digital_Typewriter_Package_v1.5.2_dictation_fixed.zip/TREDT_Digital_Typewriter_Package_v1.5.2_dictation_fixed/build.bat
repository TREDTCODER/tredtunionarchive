@echo off
setlocal EnableExtensions
title TREDT Digital Typewriter v1.5.2 - Build

echo.
echo ============================================================
echo   TREDT DIGITAL TYPEWRITER v1.5.2
echo   Windows Build Script
echo ============================================================
echo.

cd /d "%~dp0"

echo [1/6] Checking Python...
py -3.14 --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.14 was not found through the py launcher.
    echo.
    echo Try:
    echo     py --version
    echo.
    pause
    exit /b 1
)

py -3.14 --version
echo.

echo [2/6] Installing/updating build dependencies...
py -3.14 -m pip install --upgrade pip
if errorlevel 1 goto :pip_error

py -3.14 -m pip install --upgrade pyinstaller sounddevice numpy SpeechRecognition Pillow
if errorlevel 1 goto :pip_error
echo.

echo [3/6] Checking required Python modules...
py -3.14 -c "import tkinter, sounddevice, numpy, speech_recognition; print('Dependencies OK')"
if errorlevel 1 goto :dependency_error
echo.

echo [4/6] Removing old build output...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "__pycache__" rmdir /s /q "__pycache__"
if exist "*.spec" del /q "*.spec"

echo [5/6] Building executable...
py -3.14 -m PyInstaller --noconfirm --clean --onefile --windowed --name TREDT_Digital_Typewriter tredt_digital_typewriter.py
if errorlevel 1 goto :build_error

echo.
echo [6/6] Verifying build...
if not exist "dist\TREDT_Digital_Typewriter.exe" goto :missing_exe

echo.
echo ============================================================
echo   BUILD SUCCESSFUL
echo ============================================================
echo.
echo EXE:
echo %CD%\dist\TREDT_Digital_Typewriter.exe
echo.
echo Build folder:
echo %CD%\build
echo.
echo Dist folder:
echo %CD%\dist
echo.
pause
exit /b 0

:pip_error
echo.
echo ERROR: pip could not install the required packages.
echo Check the error above.
pause
exit /b 2

:dependency_error
echo.
echo ERROR: One or more Python dependencies could not be imported.
pause
exit /b 3

:build_error
echo.
echo ERROR: PyInstaller failed to build the executable.
echo Check the PyInstaller error above.
pause
exit /b 4

:missing_exe
echo.
echo ERROR: PyInstaller finished but the EXE was not found in dist.
pause
exit /b 5
