import tkinter as tk
import sounddevice as sd
import numpy as np
from tkinter import filedialog, messagebox, font
import os
import time
import threading
import queue
import math

try:
    from PIL import Image, ImageDraw, ImageTk
except ImportError:
    Image = ImageDraw = ImageTk = None

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import winsound
except ImportError:
    winsound = None

APP_NAME = "TREDT Digital Typewriter"
LICENSE_NAME = "TREDT Publications Studios"
VERSION = "1.5.2"
INTRO_DURATION_MS = 15000


DOS_COLORS = [
    ("Black", "#000000"), ("Blue", "#000080"), ("Green", "#008000"),
    ("Cyan", "#008080"), ("Red", "#800000"), ("Magenta", "#800080"),
    ("Brown", "#808000"), ("Light Gray", "#C0C0C0"), ("Dark Gray", "#808080"),
    ("Bright Blue", "#0000FF"), ("Bright Green", "#00FF00"),
    ("Bright Cyan", "#00FFFF"), ("Bright Red", "#FF0000"),
    ("Bright Magenta", "#FF00FF"), ("Yellow", "#FFFF00"), ("White", "#FFFFFF")
]


class DigitalTypewriter:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} — Licensed to {LICENSE_NAME}")
        self.root.geometry("1040x700")
        self.root.minsize(720, 460)
        self.root.configure(bg="#000000")

        self.current_file = None
        self.modified = False
        # Original is the green-phosphor DOS-style theme.
        self.bg_color = "#000000"
        self.editor_bg_color = "#000000"
        self.fg_color = "#00FF00"
        self.beep_enabled = True
        self.editor_font = self.choose_dos_font()
        self.dictation_active = False
        self.dictation_stop = threading.Event()
        self.dictation_queue = queue.Queue()
        self.audio_level = 0.0
        self.audio_history = [0.0] * 64
        self.voice_graph_items = None
        self.editor_font_size = 16
        self.format_tags = set()
        self.signature_assets = []
        self.stamp_assets = []
        self.inserted_images = []
        self.sound_queue = queue.Queue(maxsize=1)
        self.audio_stream = None
        self._dictation_audio_queue = queue.Queue()
        self.recognizer = None
        self.recognition_thread = None
        threading.Thread(target=self._sound_worker, daemon=True).start()

        self.build_ui()
        self.apply_theme()
        self._start_amplitude_monitor()
        self.bind_keys()
        self.update_title()

    def choose_dos_font(self):
        available = set(font.families(self.root))
        for name in ("Fixedsys", "Terminal", "Lucida Console", "Consolas", "Courier New"):
            if name in available:
                return name
        return "Courier New"

    def build_ui(self):
        self.menu_bar = tk.Frame(self.root)
        self.menu_bar.pack(fill="x", side="top")

        for label, command in [
            ("File", self.show_file_menu),
            ("Edit", self.show_edit_menu),
            ("B", lambda: self.toggle_text_format("bold")),
            ("I", lambda: self.toggle_text_format("italic")),
            ("U", lambda: self.toggle_text_format("underline")),
            ("X²", lambda: self.toggle_text_format("superscript")),
            ("X₂", lambda: self.toggle_text_format("subscript")),
            ("Left", lambda: self.set_alignment("left")),
            ("Center", lambda: self.set_alignment("center")),
            ("Right", lambda: self.set_alignment("right")),
            ("Stamp", self.show_stamp_menu),
            ("Sign", self.show_signature_menu),
            ("Theme", self.show_theme_menu),
            ("Help", self.show_help),
            ("Dictate", self.toggle_dictation),
        ]:
            tk.Button(
                self.menu_bar, text=label, command=command,
                font=(self.editor_font, 10), relief="flat", bd=0,
                padx=12, pady=4, highlightthickness=0
            ).pack(side="left")

        self.status = tk.Label(
            self.root, text="READY", anchor="w",
            font=(self.editor_font, 10), padx=8, pady=3
        )
        self.status.pack(fill="x", side="bottom")

        frame = tk.Frame(self.root)
        frame.pack(fill="both", expand=True, padx=10, pady=(5, 2))

        # Fixed 256x256 live microphone monitor, anchored at the bottom-right.
        # It is created here, before apply_theme(), so theme application can
        # safely configure these widgets during startup.
        self.voice_holder = tk.Frame(frame, width=256, height=256, bd=1, relief="solid")
        self.voice_holder.pack(side="right", fill="y", padx=(8, 0), pady=0)
        self.voice_holder.pack_propagate(False)

        self.voice_panel = tk.Frame(self.voice_holder, width=256, height=256, bd=0)
        self.voice_panel.pack(side="bottom", anchor="e")
        self.voice_panel.pack_propagate(False)

        self.voice_title = tk.Label(
            self.voice_panel, text="VOICE AMPLITUDE  •  MIC",
            anchor="w", font=(self.editor_font, 9), padx=6, pady=3
        )
        self.voice_title.pack(fill="x")

        self.voice_canvas = tk.Canvas(
            self.voice_panel, width=256, height=230, bd=0,
            highlightthickness=0
        )
        self.voice_canvas.pack(fill="both", expand=True)

        text_frame = tk.Frame(frame)
        text_frame.pack(fill="both", expand=True, side="left")

        self.text = tk.Text(
            text_frame, wrap="none", undo=True, autoseparators=True, maxundo=-1,
            padx=12, pady=10, borderwidth=0, highlightthickness=0,
            insertwidth=2, selectborderwidth=0,
            font=(self.editor_font, self.editor_font_size), spacing1=0, spacing2=0, spacing3=0
        )
        self.text.pack(fill="both", expand=True, side="left")

        self.ybar = tk.Scrollbar(text_frame, command=self.text.yview, width=14)
        self.ybar.pack(side="right", fill="y")
        self.xbar = tk.Scrollbar(
            text_frame, command=self.text.xview, orient="horizontal", width=14
        )
        self.xbar.pack(side="bottom", fill="x")
        self.text.configure(
            yscrollcommand=self._update_y_scrollbar,
            xscrollcommand=self._update_x_scrollbar,
        )
        self.text.bind("<<Modified>>", self.on_modified)
        self._configure_format_tags()
        self.text.focus_set()

        self.theme_panel = tk.Frame(self.root, bd=1, relief="solid")
        self.theme_visible = False

    def _update_y_scrollbar(self, first, last):
        self.ybar.set(first, last)
        needed = float(first) > 0.0 or float(last) < 1.0
        if needed and not self.ybar.winfo_manager():
            self.ybar.pack(side="right", fill="y")
        elif not needed and self.ybar.winfo_manager():
            self.ybar.pack_forget()

    def _update_x_scrollbar(self, first, last):
        self.xbar.set(first, last)
        needed = float(first) > 0.0 or float(last) < 1.0
        if needed and not self.xbar.winfo_manager():
            self.xbar.pack(side="bottom", fill="x")
        elif not needed and self.xbar.winfo_manager():
            self.xbar.pack_forget()

    def bind_keys(self):
        self.root.bind("<Control-n>", lambda e: self.new_file())
        self.root.bind("<Control-o>", lambda e: self.open_file())
        self.root.bind("<Control-s>", lambda e: self.save_file())
        self.root.bind("<Control-Shift-S>", lambda e: self.save_as())
        self.root.bind("<Control-q>", lambda e: self.quit_app())
        self.root.bind("<F1>", lambda e: self.show_help())
        self.text.bind("<Control-b>", lambda e: self.toggle_text_format("bold"))
        self.text.bind("<Control-i>", lambda e: self.toggle_text_format("italic"))
        self.text.bind("<Control-u>", lambda e: self.toggle_text_format("underline"))
        self.text.bind("<Control-plus>", lambda e: self.toggle_text_format("superscript"))
        self.text.bind("<Control-equal>", lambda e: self.toggle_text_format("superscript"))
        self.text.bind("<Control-Shift-equal>", lambda e: self.toggle_text_format("superscript"))
        self.text.bind("<Control-minus>", lambda e: self.toggle_text_format("subscript"))
        self.text.bind("<Control-l>", lambda e: self.set_alignment("left"))
        self.text.bind("<Control-e>", lambda e: self.set_alignment("center"))
        self.text.bind("<Control-r>", lambda e: self.set_alignment("right"))
        self.text.bind("<KeyPress>", self.key_beep)
        self.root.bind("<F2>", lambda e: self.toggle_dictation())
        self.root.after(50, self.process_dictation_queue)
        self.root.after(100, self.update_voice_graph)

    def key_beep(self, event):
        if self.beep_enabled and winsound and (
            event.keysym in ("Return", "BackSpace", "Delete") or
            (event.char and event.char.isprintable())
        ):
            self.sound(880, 10)

    def _sound_worker(self):
        """Play typewriter sounds off the Tk event loop to prevent key lag."""
        while True:
            frequency, duration = self.sound_queue.get()
            try:
                if winsound:
                    winsound.Beep(frequency, duration)
            except Exception:
                pass

    def _configure_format_tags(self):
        """Create composite tags so bold, italic, underline, and script combine."""
        for bits in range(32):
            parts = []
            if bits & 1:
                parts.append("bold")
            if bits & 2:
                parts.append("italic")
            if bits & 4:
                parts.append("underline")
            if bits & 8:
                parts.append("superscript")
            if bits & 16:
                parts.append("subscript")
            tag = "fmt_" + ("_".join(parts) if parts else "plain")
            size = self.editor_font_size - 4 if bits & (8 | 16) else self.editor_font_size
            style = " ".join(
                name for flag, name in ((1, "bold"), (2, "italic")) if bits & flag
            ) or "normal"
            offset = 6 if bits & 8 else (-4 if bits & 16 else 0)
            self.text.tag_configure(
                tag, font=(self.editor_font, size, style),
                underline=bool(bits & 4), offset=offset
            )
            self.format_tags.add(tag)

        for alignment in ("left", "center", "right"):
            self.text.tag_configure(f"align_{alignment}", justify=alignment)

    def _selection_range(self, notify=True):
        try:
            return self.text.index("sel.first"), self.text.index("sel.last")
        except tk.TclError:
            if notify:
                self.set_status("SELECT TEXT FIRST")
                self.sound(400, 25)
            return None

    def _format_bits_at(self, index):
        tags = self.text.tag_names(index)
        tag = next((name for name in tags if name.startswith("fmt_")), "fmt_plain")
        parts = set(tag.removeprefix("fmt_").split("_"))
        return (
            (1 if "bold" in parts else 0)
            | (2 if "italic" in parts else 0)
            | (4 if "underline" in parts else 0)
            | (8 if "superscript" in parts else 0)
            | (16 if "subscript" in parts else 0)
        )

    def _format_tag_for_bits(self, bits):
        names = []
        for flag, name in ((1, "bold"), (2, "italic"), (4, "underline"),
                           (8, "superscript"), (16, "subscript")):
            if bits & flag:
                names.append(name)
        return "fmt_" + ("_".join(names) if names else "plain")

    def toggle_text_format(self, format_name):
        selection = self._selection_range()
        if not selection:
            return "break"
        start, end = selection
        flag = {
            "bold": 1, "italic": 2, "underline": 4,
            "superscript": 8, "subscript": 16,
        }[format_name]
        bits = self._format_bits_at(start) ^ flag
        if format_name == "superscript":
            bits &= ~16
        elif format_name == "subscript":
            bits &= ~8
        for tag in self.format_tags:
            self.text.tag_remove(tag, start, end)
        self.text.tag_add(self._format_tag_for_bits(bits), start, end)
        self.modified = True
        self.update_title()
        self.set_status(f"{format_name.upper()}: ON" if bits & flag else f"{format_name.upper()}: OFF")
        return "break"

    def set_alignment(self, alignment):
        selection = self._selection_range(notify=False)
        if selection:
            start, end = selection
            start = self.text.index(f"{start} linestart")
            end = self.text.index(f"{end} lineend +1c")
        else:
            start = self.text.index("insert linestart")
            end = self.text.index("insert lineend +1c")
        for tag in ("align_left", "align_center", "align_right"):
            self.text.tag_remove(tag, start, end)
        self.text.tag_add(f"align_{alignment}", start, end)
        self.modified = True
        self.update_title()
        self.set_status(f"ALIGNMENT: {alignment.upper()}")
        return "break"

    def apply_theme(self):
        self.root.configure(bg=self.bg_color)
        self.menu_bar.configure(bg=self.bg_color)
        self.status.configure(bg=self.bg_color, fg=self.fg_color)
        self.voice_panel.configure(bg=self.bg_color)
        self.voice_title.configure(bg=self.bg_color, fg=self.fg_color)
        self.voice_canvas.configure(bg=self.editor_bg_color)
        # Native Tk scrollbars otherwise retain Windows' bright default
        # trough, creating a distracting white strip beside the page.
        for scrollbar in (self.ybar, self.xbar):
            scrollbar.configure(
                bg=self.bg_color,
                activebackground=self.fg_color,
                troughcolor=self.bg_color,
                highlightbackground=self.bg_color,
                highlightcolor=self.bg_color,
            )
        self.text.configure(
            bg=self.editor_bg_color, fg=self.fg_color,
            insertbackground=self.fg_color,
            selectbackground=self.fg_color,
            selectforeground=self.editor_bg_color
        )
        for child in self.menu_bar.winfo_children():
            child.configure(
                bg=self.bg_color, fg=self.fg_color,
                activebackground=self.fg_color,
                activeforeground=self.bg_color
            )
        if self.theme_visible:
            self.update_theme_panel_colors()

    def show_theme_menu(self):
        m = tk.Menu(self.root, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        m.add_command(label="Original", command=self.set_original_theme)
        m.add_command(label="Windows NT 4", command=self.set_windows_nt4_theme)
        m.add_separator()
        m.add_command(label="Custom DOS Colors...", command=self.show_theme_panel)
        try:
            m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            m.grab_release()

    def set_original_theme(self):
        self.bg_color = "#000000"
        self.editor_bg_color = "#000000"
        self.fg_color = "#00FF00"
        self.apply_theme()
        self.set_status("THEME: ORIGINAL GREEN PHOSPHOR")

    def set_windows_nt4_theme(self):
        # Classic Windows NT 4 chrome with a white document surface.
        self.bg_color = "#C0C0C0"
        self.editor_bg_color = "#FFFFFF"
        self.fg_color = "#000000"
        self.apply_theme()
        self.set_status("THEME: WINDOWS NT 4")

    def show_theme_panel(self):
        if self.theme_visible:
            self.theme_panel.pack_forget()
            self.theme_visible = False
            return
        self.theme_visible = True
        self.theme_panel.pack(fill="x", side="top", padx=10, pady=(0, 5))
        self.build_theme_panel()
        self.update_theme_panel_colors()

    def build_theme_panel(self):
        for w in self.theme_panel.winfo_children():
            w.destroy()

        tk.Label(
            self.theme_panel,
            text="THEME SELECTOR — choose BACKGROUND or TEXT, then click a DOS color",
            font=(self.editor_font, 10), anchor="w"
        ).pack(fill="x", padx=8, pady=(6, 2))

        controls = tk.Frame(self.theme_panel)
        controls.pack(fill="x", padx=8, pady=4)

        self.target_var = tk.StringVar(value="bg")
        tk.Radiobutton(
            controls, text="Background", variable=self.target_var, value="bg",
            font=(self.editor_font, 10), indicatoron=False, padx=8
        ).pack(side="left", padx=2)
        tk.Radiobutton(
            controls, text="Text", variable=self.target_var, value="fg",
            font=(self.editor_font, 10), indicatoron=False, padx=8
        ).pack(side="left", padx=2)

        self.beep_var = tk.BooleanVar(value=self.beep_enabled)
        tk.Checkbutton(
            controls, text="Key Beep", variable=self.beep_var,
            command=self.toggle_beep, font=(self.editor_font, 10)
        ).pack(side="right", padx=5)

        swatches = tk.Frame(self.theme_panel)
        swatches.pack(fill="x", padx=8, pady=(0, 7))

        for name, color in DOS_COLORS:
            b = tk.Button(
                swatches, width=2, height=1, bg=color, activebackground=color,
                relief="raised", bd=2, command=lambda c=color: self.choose_color(c)
            )
            b.pack(side="left", padx=2)
            b.bind("<Enter>", lambda e, n=name: self.set_status(f"COLOR: {n.upper()}"))
            b.bind("<Leave>", lambda e: self.set_status("READY"))

    def update_theme_panel_colors(self):
        self.theme_panel.configure(bg=self.bg_color)
        for child in self.theme_panel.winfo_children():
            try:
                child.configure(bg=self.bg_color, fg=self.fg_color)
            except tk.TclError:
                pass
            for sub in child.winfo_children():
                try:
                    sub.configure(
                        bg=self.bg_color, fg=self.fg_color,
                        activebackground=self.fg_color,
                        activeforeground=self.bg_color,
                        selectcolor=self.bg_color
                    )
                except tk.TclError:
                    pass

    def choose_color(self, color):
        if self.target_var.get() == "bg":
            self.bg_color = color
            self.editor_bg_color = color
            label = "BACKGROUND"
        else:
            self.fg_color = color
            label = "TEXT"
        self.apply_theme()
        self.set_status(f"{label} = {color.upper()}")

    def toggle_beep(self):
        self.beep_enabled = bool(self.beep_var.get())
        self.set_status("KEY BEEP: ON" if self.beep_enabled else "KEY BEEP: OFF")

    def toggle_dictation(self):
        if self.dictation_active:
            self.stop_dictation()
        else:
            self.start_dictation()

    def start_dictation(self):
        if sr is None or sd is None or np is None:
            messagebox.showerror(
                "DICTATION",
                "Dictation requires SpeechRecognition, sounddevice, and NumPy.\n\n"
                "Install them with:\n"
                "py -3.14 -m pip install SpeechRecognition sounddevice numpy"
            )
            return
        if self.dictation_active:
            return

        try:
            self._stop_amplitude_monitor()
            self.recognizer = sr.Recognizer()
            self.recognizer.pause_threshold = 0.8
            self.recognizer.non_speaking_duration = 0.3
            self.dictation_active = True
            self.dictation_stop.clear()
            self.set_status("DICTATION: LISTENING...  F2 TO STOP")
            self.recognition_thread = threading.Thread(
                target=self._dictation_loop, daemon=True
            )
            self.recognition_thread.start()
        except Exception as exc:
            self.dictation_active = False
            self._start_amplitude_monitor()
            messagebox.showerror("DICTATION", f"Could not start microphone:\n{exc}")

    def stop_dictation(self):
        self.dictation_active = False
        self.dictation_stop.set()
        self._stop_amplitude_monitor()
        self.set_status("DICTATION: STOPPED")
        # Restart the idle monitor after dictation has stopped.
        if self.root.winfo_exists():
            self.root.after(150, self._restart_idle_monitor)

    def _restart_idle_monitor(self):
        if not self.dictation_active:
            self._start_amplitude_monitor()

    def _dictation_loop(self):
        """Capture microphone audio with sounddevice and convert speech to text."""
        sample_rate = 16000
        block_duration = 0.20
        block_size = int(sample_rate * block_duration)
        silence_limit = 0.80
        max_phrase_seconds = 8.0

        audio_blocks = []
        pre_roll = []
        speaking = False
        silence_time = 0.0
        noise_floor = 0.008

        def callback(indata, frames, time_info, status):
            try:
                data = np.asarray(indata, dtype=np.int16).copy()
                if data.size:
                    mono = data[:, 0] if data.ndim > 1 else data
                    normalized = mono.astype(np.float32) / 32768.0
                    rms = float(np.sqrt(np.mean(normalized * normalized)))
                    peak = float(np.max(np.abs(normalized)))

                    # Update the same live amplitude graph while dictating.
                    self.audio_level = min(
                        1.0, max(rms * 8.0, peak * 0.55)
                    )
                    self._dictation_audio_queue.put(mono.tobytes())
            except Exception:
                pass

        self._dictation_audio_queue = queue.Queue()
        stream = None

        try:
            # Use the Windows default input device.
            stream = sd.InputStream(
                samplerate=sample_rate,
                channels=1,
                dtype="int16",
                blocksize=block_size,
                callback=callback
            )
            stream.start()

            self.dictation_queue.put(
                ("status", "DICTATION: LISTENING — SPEAK NOW")
            )

            while not self.dictation_stop.is_set():
                try:
                    raw = self._dictation_audio_queue.get(timeout=0.5)
                except queue.Empty:
                    continue

                samples = np.frombuffer(raw, dtype=np.int16)
                if samples.size == 0:
                    continue

                normalized = samples.astype(np.float32) / 32768.0
                rms = float(np.sqrt(np.mean(normalized * normalized)))

                # Keep a small pre-roll so the first syllable is not clipped.
                pre_roll.append(raw)
                if len(pre_roll) > 3:
                    pre_roll.pop(0)

                # Adaptive threshold. This is deliberately lower than the old
                # fixed 0.025 threshold so normal laptop/headset microphones
                # can trigger speech recognition.
                if not speaking:
                    noise_floor = min(
                        0.025,
                        max(0.004, noise_floor * 0.95 + rms * 0.05)
                    )

                speech_threshold = max(0.010, noise_floor * 2.2)

                if rms >= speech_threshold:
                    if not speaking:
                        speaking = True
                        audio_blocks = list(pre_roll)
                    audio_blocks.append(raw)
                    silence_time = 0.0

                    self.dictation_queue.put(
                        ("status", "DICTATION: HEARING YOU...")
                    )

                elif speaking:
                    audio_blocks.append(raw)
                    silence_time += block_duration

                total_seconds = len(audio_blocks) * block_duration

                # A short pause finishes the current phrase. A long phrase is
                # also submitted automatically so recognition doesn't wait
                # forever if the user keeps speaking.
                if speaking and (
                    silence_time >= silence_limit
                    or total_seconds >= max_phrase_seconds
                ):
                    phrase_bytes = b"".join(audio_blocks)
                    audio_blocks = []
                    speaking = False
                    silence_time = 0.0

                    if len(phrase_bytes) < int(sample_rate * 2 * 0.30):
                        continue

                    try:
                        audio = sr.AudioData(
                            phrase_bytes,
                            sample_rate,
                            2
                        )
                        phrase = self.recognizer.recognize_google(audio)

                        if phrase and phrase.strip():
                            # This is consumed by the Tkinter main thread,
                            # which safely inserts it into the editor.
                            self.dictation_queue.put(
                                ("text", phrase.strip())
                            )
                            self.dictation_queue.put(
                                ("status", "DICTATION: LISTENING — SPEAK NOW")
                            )

                    except sr.UnknownValueError:
                        self.dictation_queue.put(
                            ("status", "DICTATION: DID NOT RECOGNIZE — TRY AGAIN")
                        )
                    except sr.RequestError as exc:
                        self.dictation_queue.put(
                            ("error",
                             "Google speech recognition could not be reached.\n\n"
                             f"{exc}\n\n"
                             "Check your internet connection.")
                        )
                        break
                    except Exception as exc:
                        self.dictation_queue.put(
                            ("status", f"DICTATION ERROR: {exc}")
                        )

        except Exception as exc:
            self.dictation_queue.put(
                ("error", f"Microphone error:\n\n{exc}")
            )
        finally:
            try:
                if stream is not None:
                    stream.stop()
                    stream.close()
            except Exception:
                pass
            self.audio_level = 0.0
            self.dictation_queue.put(("stopped", ""))

    def _start_amplitude_monitor(self):
        if sd is None or np is None or self.dictation_active:
            return
        if self.audio_stream is not None:
            return

        try:
            def callback(indata, frames, time_info, status):
                try:
                    data = np.asarray(indata, dtype=np.float32)
                    if data.size:
                        mono = data[:, 0] if data.ndim > 1 else data
                        rms = float(np.sqrt(np.mean(np.square(mono))))
                        peak = float(np.max(np.abs(mono)))
                        self.audio_level = min(
                            1.0, max(rms * 7.0, peak * 0.5)
                        )
                except Exception:
                    self.audio_level = 0.0

            self.audio_stream = sd.InputStream(
                channels=1,
                samplerate=16000,
                blocksize=512,
                dtype="float32",
                callback=callback
            )
            self.audio_stream.start()
        except Exception:
            self.audio_stream = None
            self.audio_level = 0.0

    def _stop_amplitude_monitor(self):
        try:
            if self.audio_stream is not None:
                self.audio_stream.stop()
                self.audio_stream.close()
        except Exception:
            pass
        self.audio_stream = None
        self.audio_level = 0.0

    def process_dictation_queue(self):
        try:
            while True:
                kind, value = self.dictation_queue.get_nowait()
                if kind == "text":
                    # Tkinter widgets must be modified on the main thread.
                    self.text.focus_set()
                    self.text.insert("insert", value.strip() + " ")
                    self.text.see("insert")
                    self.modified = True
                    self.update_title()
                    self.set_status(f"DICTATION: {value.upper()}")
                elif kind == "status":
                    self.set_status(value)
                elif kind == "error":
                    self.stop_dictation()
                    messagebox.showerror("DICTATION", value)
                elif kind == "stopped":
                    if self.dictation_active:
                        self.stop_dictation()
        except queue.Empty:
            pass
        self.root.after(50, self.process_dictation_queue)

    def draw_voice_graph(self):
        if not hasattr(self, "voice_canvas"):
            return
        c = self.voice_canvas
        w = max(256, c.winfo_width())
        h = max(230, c.winfo_height())

        # The grid and labels are created just once. Reusing canvas objects
        # avoids hundreds of allocations a second and keeps the editor smooth.
        if self.voice_graph_items is None:
            grid = []
            for y in range(10, h, 25):
                grid.append(c.create_line(0, y, w, y, fill="#202020"))
            for x in range(0, w, 32):
                grid.append(c.create_line(x, 0, x, h, fill="#151515"))
            grid.append(c.create_line(0, h // 2, w, h // 2, fill="#404040"))
            self.voice_graph_items = {
                "grid": grid,
                "upper": c.create_line(0, 0, 0, 0, fill=self.fg_color, width=2, smooth=True),
                "lower": c.create_line(0, 0, 0, 0, fill=self.fg_color, width=2, smooth=True),
                "title": c.create_text(7, 7, text="MIC / LIVE", anchor="nw", fill=self.fg_color, font=(self.editor_font, 8)),
                "level": c.create_text(w - 7, 7, anchor="ne", fill=self.fg_color, font=(self.editor_font, 8)),
            }

        history = self.audio_history
        pts = []
        center = h / 2
        for i, level in enumerate(history):
            x = 3 + i * (w - 6) / max(1, len(history) - 1)
            amplitude = min(1.0, level) * (h * 0.42)
            # Mirror the amplitude around the center so speech produces a
            # visible live waveform envelope.
            y = center - amplitude
            pts.extend((x, y))
        if len(pts) >= 4:
            c.coords(self.voice_graph_items["upper"], *pts)

        lower = []
        for i, level in enumerate(history):
            x = 3 + i * (w - 6) / max(1, len(history) - 1)
            amplitude = min(1.0, level) * (h * 0.42)
            y = center + amplitude
            lower.extend((x, y))
        if len(lower) >= 4:
            c.coords(self.voice_graph_items["lower"], *lower)

        for item in ("upper", "lower", "title", "level"):
            c.itemconfigure(self.voice_graph_items[item], fill=self.fg_color)
        c.itemconfigure(self.voice_graph_items["level"], text=f"{self.audio_level * 100:03.0f}%")

    def update_voice_graph(self):
        level = max(0.0, min(1.0, float(self.audio_level)))
        self.audio_history.append(level)
        self.audio_history = self.audio_history[-64:]
        self.draw_voice_graph()
        self.root.after(100, self.update_voice_graph)

    def show_file_menu(self):
        m = tk.Menu(self.root, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        m.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        m.add_command(label="Open...", command=self.open_file, accelerator="Ctrl+O")
        m.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        m.add_command(label="Save As...", command=self.save_as, accelerator="Ctrl+Shift+S")
        m.add_separator()
        m.add_command(label="Exit", command=self.quit_app, accelerator="Ctrl+Q")
        try:
            m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            m.grab_release()

    def show_edit_menu(self):
        m = tk.Menu(self.root, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        for label, event in [
            ("Undo", "<<Undo>>"), ("Redo", "<<Redo>>"),
            ("Cut", "<<Cut>>"), ("Copy", "<<Copy>>"),
            ("Paste", "<<Paste>>"), ("Select All", "<<SelectAll>>")
        ]:
            m.add_command(label=label, command=lambda ev=event: self.text.event_generate(ev))
        m.add_separator()
        format_menu = tk.Menu(m, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        for label, name, shortcut in [
            ("Bold", "bold", "Ctrl+B"),
            ("Italic", "italic", "Ctrl+I"),
            ("Underline", "underline", "Ctrl+U"),
            ("Superscript", "superscript", "Ctrl++"),
            ("Subscript", "subscript", "Ctrl+-"),
        ]:
            format_menu.add_command(
                label=label, accelerator=shortcut,
                command=lambda n=name: self.toggle_text_format(n)
            )
        m.add_cascade(label="Format", menu=format_menu)
        align_menu = tk.Menu(m, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        for label, name, shortcut in [
            ("Left", "left", "Ctrl+L"),
            ("Center", "center", "Ctrl+E"),
            ("Right", "right", "Ctrl+R"),
        ]:
            align_menu.add_command(
                label=label, accelerator=shortcut,
                command=lambda n=name: self.set_alignment(n)
            )
        m.add_cascade(label="Alignment", menu=align_menu)
        try:
            m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            m.grab_release()

    def _image_support_available(self):
        if Image is not None:
            return True
        messagebox.showerror(
            APP_NAME,
            "Images require Pillow. Rebuild with build.bat, or install Pillow first."
        )
        return False

    def show_signature_menu(self):
        self._show_asset_menu("signature")

    def show_stamp_menu(self):
        self._show_asset_menu("stamp")

    def _show_asset_menu(self, kind):
        assets = self.signature_assets if kind == "signature" else self.stamp_assets
        limit = 7 if kind == "signature" else 3
        label = "SIGNATURE" if kind == "signature" else "STAMP"
        m = tk.Menu(self.root, tearoff=0, bg=self.bg_color, fg=self.fg_color)
        if kind == "signature":
            m.add_command(label="Draw signature...", command=self.draw_signature)
        if len(assets) < limit:
            m.add_command(
                label=f"Add {label.lower()} image... ({len(assets)}/{limit})",
                command=lambda: self.add_asset(kind)
            )
        else:
            m.add_command(label=f"{label} LIBRARY FULL ({limit}/{limit})", state="disabled")
        if assets:
            m.add_separator()
            for number, path in enumerate(assets, start=1):
                m.add_command(
                    label=f"Insert {label.title()} {number}: {os.path.basename(path)}",
                    command=lambda p=path, k=kind: self.insert_asset(p, k)
                )
            m.add_separator()
            m.add_command(label=f"Clear {label.title()} Library", command=lambda: self.clear_assets(kind))
        try:
            m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            m.grab_release()

    def add_asset(self, kind):
        if not self._image_support_available():
            return
        limit = 7 if kind == "signature" else 3
        assets = self.signature_assets if kind == "signature" else self.stamp_assets
        if len(assets) >= limit:
            self.set_status(f"{kind.upper()} LIBRARY FULL ({limit} MAXIMUM)")
            return
        path = filedialog.askopenfilename(
            title=f"Choose {kind} image",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp"), ("All files", "*.*")]
        )
        if path:
            assets.append(path)
            self.set_status(f"{kind.upper()} SAVED ({len(assets)}/{limit})")

    def clear_assets(self, kind):
        label = "signatures" if kind == "signature" else "stamps"
        if messagebox.askyesno(APP_NAME, f"Remove all saved {label} from this session?"):
            if kind == "signature":
                self.signature_assets.clear()
            else:
                self.stamp_assets.clear()
            self.set_status(f"{label.upper()} CLEARED")

    def insert_asset(self, path, kind):
        if not self._image_support_available():
            return
        try:
            image = Image.open(path).convert("RGBA")
            image.thumbnail((360, 180), Image.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            self.text.image_create("insert", image=photo, padx=6, pady=4)
            self.inserted_images.append(photo)  # Prevent Tk from releasing it.
            self.text.insert("insert", "\n")
            self.text.see("insert")
            self.modified = True
            self.update_title()
            self.set_status(f"{kind.upper()} INSERTED")
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Could not insert image:\n{exc}")

    def draw_signature(self):
        if not self._image_support_available():
            return
        if len(self.signature_assets) >= 7:
            self.set_status("SIGNATURE LIBRARY FULL (7 MAXIMUM)")
            return

        win = tk.Toplevel(self.root)
        win.title("Draw Signature")
        win.configure(bg=self.bg_color)
        tk.Label(
            win, text="DRAW WITH THE MOUSE, THEN SAVE AND INSERT",
            bg=self.bg_color, fg=self.fg_color, font=(self.editor_font, 10)
        ).pack(fill="x", padx=10, pady=(10, 4))
        canvas = tk.Canvas(win, width=620, height=190, bg="white", highlightthickness=1)
        canvas.pack(padx=10, pady=4)
        drawing = Image.new("RGBA", (620, 190), (255, 255, 255, 0))
        pen = ImageDraw.Draw(drawing)
        state = {"last": None}

        def begin(event):
            state["last"] = (event.x, event.y)

        def stroke(event):
            if state["last"] is None:
                begin(event)
                return
            x0, y0 = state["last"]
            canvas.create_line(x0, y0, event.x, event.y, fill="#111111", width=3, capstyle="round", smooth=True)
            pen.line((x0, y0, event.x, event.y), fill=(17, 17, 17, 255), width=3)
            state["last"] = (event.x, event.y)

        def finish_stroke(event):
            state["last"] = None

        def clear():
            canvas.delete("all")
            drawing.paste((255, 255, 255, 0), (0, 0, 620, 190))

        def save_and_insert():
            if drawing.getbbox() is None:
                messagebox.showwarning(APP_NAME, "Draw a signature before saving.", parent=win)
                return
            folder = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), APP_NAME)
            try:
                os.makedirs(folder, exist_ok=True)
                path = os.path.join(folder, f"signature_{int(time.time() * 1000)}.png")
                drawing.save(path, "PNG")
                self.signature_assets.append(path)
                win.destroy()
                self.insert_asset(path, "signature")
            except OSError as exc:
                messagebox.showerror(APP_NAME, f"Could not save signature:\n{exc}", parent=win)

        canvas.bind("<Button-1>", begin)
        canvas.bind("<B1-Motion>", stroke)
        canvas.bind("<ButtonRelease-1>", finish_stroke)
        buttons = tk.Frame(win, bg=self.bg_color)
        buttons.pack(fill="x", padx=10, pady=(4, 10))
        tk.Button(buttons, text="Clear", command=clear).pack(side="left")
        tk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right")
        tk.Button(buttons, text="Save and Insert", command=save_and_insert).pack(side="right", padx=5)

    def new_file(self):
        if not self.confirm_discard():
            return
        self.text.delete("1.0", "end")
        self.current_file = None
        self.modified = False
        self.text.edit_modified(False)
        self.update_title()
        self.set_status("NEW DOCUMENT")

    def open_file(self):
        if not self.confirm_discard():
            return
        path = filedialog.askopenfilename(
            title="Open Text File",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
                data = f.read()
            self.text.delete("1.0", "end")
            self.text.insert("1.0", data)
            self.text.edit_modified(False)
            self.current_file = path
            self.modified = False
            self.update_title()
            self.set_status(f"OPENED: {os.path.basename(path)}")
            self.sound(660, 35)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"Could not open file:\n{exc}")

    def save_file(self):
        return self.save_as() if not self.current_file else self.write_file(self.current_file)

    def save_as(self):
        path = filedialog.asksaveasfilename(
            title="Save Text File", defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        return self.write_file(path) if path else False

    def write_file(self, path):
        try:
            with open(path, "w", encoding="utf-8", newline="") as f:
                f.write(self.text.get("1.0", "end-1c"))
            self.current_file = path
            self.modified = False
            self.text.edit_modified(False)
            self.update_title()
            self.set_status(f"SAVED: {os.path.basename(path)}")
            self.sound(660, 35)
            return True
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"Could not save file:\n{exc}")
            return False

    def on_modified(self, event=None):
        try:
            self.modified = bool(self.text.edit_modified())
            self.update_title()
        except tk.TclError:
            pass

    def update_title(self):
        name = os.path.basename(self.current_file) if self.current_file else "UNTITLED.TXT"
        star = " *" if self.modified else ""
        self.root.title(f"{name}{star} — {APP_NAME} — Licensed to {LICENSE_NAME}")

    def confirm_discard(self):
        if not self.modified:
            return True
        result = messagebox.askyesnocancel(
            APP_NAME, "The document has unsaved changes.\n\nSave before continuing?"
        )
        if result is None:
            return False
        return bool(self.save_file()) if result else True

    def show_help(self):
        messagebox.showinfo(
            "ABOUT / HELP",
            f"{APP_NAME} {VERSION}\n\nLicensed to {LICENSE_NAME}\n\n"
            "Vintage DOS-inspired plain-text editor.\n\n"
            "Ctrl+N New | Ctrl+O Open | Ctrl+S Save\n"
            "Ctrl+Shift+S Save As | Ctrl+Q Exit\n\n"
            "Select text, then Ctrl+B Bold | Ctrl+I Italic | Ctrl+U Underline\n"
            "Ctrl++ Superscript | Ctrl+- Subscript\n"
            "Ctrl+L Left | Ctrl+E Center | Ctrl+R Right\n\n"
            "Theme provides the 16-color DOS palette.\n"
            "Documents are ordinary TXT files compatible with Notepad.\n\n"
            "DICTATE / F2 starts and stops microphone dictation.\n"
            "Dictated words are inserted at the text cursor.\n"
            "The 256x256 panel shows live microphone amplitude."
        )

    def set_status(self, message):
        self.status.configure(text=message)

    def sound(self, frequency=800, duration=40):
        if self.beep_enabled and winsound:
            try:
                self.sound_queue.put_nowait((frequency, duration))
            except queue.Full:
                pass

    def quit_app(self):
        if self.confirm_discard():
            self.stop_dictation()
            self.root.destroy()


class BootIntro:
    """Native Tkinter port of the supplied tredt-boot.html animation.

    The supplied HTML uses a 320x240 pixelated canvas, DOS boot messages,
    star, fleur-de-lis pieces, CRT scanlines, and a 15-second timeline.
    This implementation keeps those elements inside the EXE, so no HTML
    browser or external intro file is needed.
    """

    def __init__(self, root, done):
        self.root = root
        self.done = done
        self.start = time.perf_counter()
        self.last_beep = {}
        self.dos_step = -1
        self.tredt_chars = 0
        self.sub_chars = 0
        self.flashed = False

        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.configure(bg="#000000")

        # 4:3 presentation window; canvas itself is exactly 320x240.
        self.win_w, self.win_h = 800, 600
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        self.win.geometry(
            f"{self.win_w}x{self.win_h}+{(sw-self.win_w)//2}+{(sh-self.win_h)//2}"
        )

        self.canvas = tk.Canvas(
            self.win, width=320, height=240,
            bg="#000000", highlightthickness=0
        )
        self.canvas.place(
            x=(self.win_w-640)//2, y=(self.win_h-480)//2,
            width=640, height=480
        )

        self.scale = 2
        self.c = self.canvas

        self.boot_lines = [
            "Starting TREDT TYPEWRITER...",
            "Initializing text engine...done.",
            "Loading DOS interface...done.",
            "Loading typewriter module...done."
        ]

        self.tick()

    def ms(self):
        return (time.perf_counter() - self.start) * 1000.0

    def beep(self, key, frequency=800, duration=40):
        if key in self.last_beep:
            return
        self.last_beep[key] = True
        if winsound:
            try:
                winsound.Beep(frequency, duration)
            except Exception:
                pass

    def rect(self, x, y, w, h, color):
        self.c.create_rectangle(
            x*self.scale, y*self.scale,
            (x+w)*self.scale, (y+h)*self.scale,
            fill=color, outline=""
        )

    def text(self, x, y, value, color="#CCCCCC", size=8, bold=False, anchor="nw"):
        self.c.create_text(
            x*self.scale, y*self.scale,
            text=value, fill=color,
            font=("Courier New", size*self.scale, "bold" if bold else "normal"),
            anchor=anchor
        )

    def draw_star(self, cx, cy, brightness):
        self.rect(cx-1, cy-3, 2, 6, brightness)
        self.rect(cx-3, cy-1, 6, 2, brightness)
        self.rect(cx-1, cy-1, 2, 2, brightness)

    def draw_fleur(self, center_x, center_y, center_offset, left_offset, right_offset, flash):
        main = "#FFFFFF" if flash else "#DDDDDD"
        shadow = "#FFFFFF" if flash else "#777777"

        # Center vertical piece
        if center_offset <= 0:
            y = center_offset
            self.rect(center_x-2, center_y-25+y, 4, 30, main)
            self.rect(center_x-5, center_y-5+y, 10, 4, main)
            self.rect(center_x-1, center_y-30+y, 2, 5, main)
            self.rect(center_x, center_y-25+y, 2, 30, shadow)

        # Left petal
        if left_offset >= 0:
            x = -left_offset
            self.rect(center_x-12+x, center_y-15, 8, 12, main)
            self.rect(center_x-16+x, center_y-10, 6, 15, main)
            self.rect(center_x-10+x, center_y+2, 6, 6, main)

        # Right petal
        if right_offset <= 0:
            x = -right_offset
            self.rect(center_x+4+x, center_y-15, 8, 12, main)
            self.rect(center_x+10+x, center_y-10, 6, 15, main)
            self.rect(center_x+4+x, center_y+2, 6, 6, main)
            self.rect(center_x+8+x, center_y-12, 4, 15, shadow)

    def render(self):
        elapsed = self.ms() / 1000.0
        self.c.delete("all")
        self.c.configure(bg="#000000")

        # 0-2.0 seconds: supplied DOS sequence
        if elapsed < 2.0:
            step = min(int(elapsed / 0.5), 3)
            if step != self.dos_step:
                self.dos_step = step
                self.beep(f"dos{step}", 600, 40)
            for i in range(step + 1):
                self.text(10, 12 + i*12, self.boot_lines[i], "#CCCCCC", 8)

        # 2-15 seconds: star
        if 2.0 <= elapsed < 15.0:
            twinkle = "#FFFFFF" if int(elapsed * 6) % 2 == 0 else "#666666"
            self.draw_star(160, 35, twinkle)

        # 4-6.5: center flies in
        center_offset = 0
        if 4.0 <= elapsed < 6.5:
            progress = min((elapsed - 4.0) / 2.5, 1.0)
            center_offset = (1.0 - progress) * -150

        # 6.5-8.5: petals fly in
        left_offset, right_offset = 0, 0
        if elapsed < 6.5:
            left_offset, right_offset = 160, -160
        elif 6.5 <= elapsed < 8.5:
            progress = min((elapsed - 6.5) / 2.0, 1.0)
            left_offset = (1.0 - progress) * 160
            right_offset = (1.0 - progress) * -160

        # 8.5-8.7: flash highlight
        flashing = 8.5 <= elapsed < 8.7
        if flashing and not self.flashed:
            self.flashed = True
            self.beep("flash", 1200, 80)

        if 4.0 <= elapsed < 15.0:
            self.draw_fleur(160, 100, center_offset, left_offset, right_offset, flashing)

        # 9.5-12: TREDT
        if 9.5 <= elapsed < 15.0:
            count = min(int((elapsed - 9.5) / 0.5) + 1, 5)
            if count != self.tredt_chars:
                self.tredt_chars = count
                self.beep(f"tredt{count}", 900, 30)
            self.text(
                160, 170, "TREDT"[:count], "#FFFFFF", 20, True, "n"
            )

        # 12-13.5: Typewriter
        if 12.0 <= elapsed < 15.0:
            count = min(int((elapsed - 12.0) / 0.15) + 1, 10)
            if count != self.sub_chars:
                self.sub_chars = count
                self.beep(f"sub{count}", 1100, 20)
            self.text(
                160, 190, "Typewriter"[:count], "#AAAAAA", 12, False, "n"
            )

        # Supplied HTML's CRT scanlines
        if elapsed < 15.0:
            for y in range(0, 240, 2):
                self.rect(0, y, 320, 1, "#181818")

        if elapsed >= 15.0:
            self.c.configure(bg="#000000")
            self.c.delete("all")
            self.win.after(30, self.finish)
            return

        # Thirty frames a second is smooth for this pixel-art intro while
        # avoiding needless redraw pressure on slower Windows machines.
        self.win.after(33, self.render)

    def tick(self):
        self.render()

    def finish(self):
        try:
            self.win.destroy()
        except tk.TclError:
            pass
        self.done()


def main():
    root = tk.Tk()
    root.withdraw()

    app = DigitalTypewriter(root)
    root.protocol("WM_DELETE_WINDOW", app.quit_app)

    # The intro is started BEFORE the main editor is shown.
    # It is part of the Python program and therefore part of the EXE.
    def launch_editor():
        root.deiconify()
        root.lift()
        root.focus_force()

    BootIntro(root, launch_editor)
    root.mainloop()


if __name__ == "__main__":
    main()
