@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if errorlevel 1 goto :python_missing
    set "PYTHON=python"
)

echo Installing the required build packages...
%PYTHON% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :error

echo Building dist\tredt_radio.exe...
%PYTHON% -m PyInstaller --noconfirm --clean --onefile --windowed --name tredt_radio main.py
if errorlevel 1 goto :error

echo.
echo Build complete: %CD%\dist\tredt_radio.exe
exit /b 0

:python_missing
echo.
echo Python was not found. Install Python 3, then run this file again.
exit /b 1

:error
echo.
echo Build failed. Check the messages above, then run this file again.
exit /b 1
