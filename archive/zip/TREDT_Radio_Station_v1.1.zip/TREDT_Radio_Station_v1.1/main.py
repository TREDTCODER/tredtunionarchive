import sys, time, math, shutil, subprocess, tempfile
from pathlib import Path
from datetime import datetime

import numpy as np
import sounddevice as sd
import soundfile as sf
from scipy.signal import butter, sosfilt

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QFont, QPainter, QColor, QPen, QAction
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QGridLayout, QFrame, QDialog, QDialogButtonBox, QComboBox,
    QMessageBox, QMenuBar, QLineEdit, QCheckBox
)

APP_NAME = "TREDT RADIO STATION"
FREQUENCY = "876.43 MHz"
SAMPLE_RATE = 44100
MORSE_TEXT = "TREDT RADIO STATION 876.43 MHz"
MORSE_WPM = 20
MORSE_PITCH = 550
MORSE_VOLUME = 0.15

PALETTE = [
    ("BLACK", "#000000"), ("BLUE", "#000080"), ("GREEN", "#008000"),
    ("CYAN", "#008080"), ("RED", "#800000"), ("MAGENTA", "#800080"),
    ("OLIVE", "#808000"), ("SILVER", "#C0C0C0"), ("GRAY", "#808080"),
    ("BRIGHT BLUE", "#0000FF"), ("LIME", "#00FF00"),
    ("BRIGHT CYAN", "#00FFFF"), ("BRIGHT RED", "#FF0000"),
    ("BRIGHT MAGENTA", "#FF00FF"), ("YELLOW", "#FFFF00"),
    ("WHITE", "#FFFFFF")
]

MORSE = {
    "A":".-","B":"-...","C":"-.-.","D":"-..","E":".","F":"..-.","G":"--.",
    "H":"....","I":"..","J":".---","K":"-.-","L":".-..","M":"--","N":"-.",
    "O":"---","P":".--.","Q":"--.-","R":".-.","S":"...","T":"-","U":"..-",
    "V":"...-","W":".--","X":"-..-","Y":"-.--","Z":"--..",
    "0":"-----","1":".----","2":"..---","3":"...--","4":"....-",
    "5":".....","6":"-....","7":"--...","8":"---..","9":"----.",
    ".":".-.-.-",",":"--..--","?":"..--..","/":"-..-.","-":"-....-",
    "(":"-.--.",")":"-.--.-"
}

def morse_audio(text=MORSE_TEXT):
    text = "".join(c if c in MORSE or c == " " else "" for c in text.upper())
    dot = 1.2 / MORSE_WPM
    sr = SAMPLE_RATE
    chunks = []
    rng = np.random.default_rng(87643)

    def silence(sec):
        return np.zeros(max(1, int(sec*sr)), np.float32)

    def tone(sec):
        n = max(1, int(sec*sr))
        t = np.arange(n)/sr
        y = np.sin(2*np.pi*MORSE_PITCH*t).astype(np.float32) * MORSE_VOLUME
        r = min(int(.005*sr), n//2)
        if r:
            y[:r] *= np.linspace(0,1,r)
            y[-r:] *= np.linspace(1,0,r)
        return y

    words = text.split()
    for wi, word in enumerate(words):
        for ci, char in enumerate(word):
            code = MORSE.get(char, "")
            for si, symbol in enumerate(code):
                chunks.append(tone(dot if symbol == "." else 3*dot))
                if si < len(code)-1:
                    chunks.append(silence(dot))
            if ci < len(word)-1:
                chunks.append(silence(3*dot))
        if wi < len(words)-1:
            chunks.append(silence(7*dot))
    return np.concatenate(chunks) if chunks else np.zeros(1, np.float32)

def radio_process(x):
    x = np.asarray(x, np.float32).reshape(-1)
    if not len(x):
        return x
    sos = butter(4, [250, 3600], btype="bandpass", fs=SAMPLE_RATE, output="sos")
    x = sosfilt(sos, x).astype(np.float32)
    x = np.tanh(x * 1.45)
    threshold = .22
    x = np.tanh(x / threshold) * threshold
    rng = np.random.default_rng(87643)
    hiss = rng.normal(0, .0055, len(x)).astype(np.float32)
    crack = np.zeros(len(x), np.float32)
    count = max(2, int(len(x)/SAMPLE_RATE*2))
    for idx in rng.integers(0, len(x), count):
        width = min(len(x)-idx, int(.004*SAMPLE_RATE))
        if width > 0:
            crack[idx:idx+width] += rng.uniform(-.06,.06) * np.exp(
                -np.arange(width)/(SAMPLE_RATE*.001))
    y = x*1.12 + hiss + crack
    peak = float(np.max(np.abs(y))) if len(y) else 1
    return (y/peak*.96 if peak > .96 else y).astype(np.float32)

class BootConsole(QWidget):
    finished = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(900, 560)
        self.setStyleSheet("background:#000;color:#00ff00;")
        self.lines = [
            "TREDT RADIO STATION / SYSTEM BOOT",
            "----------------------------------------",
            "Starting TREDT RADIO STATION...",
            "Loading DOS compatibility layer...",
            "Loading audio driver...",
            "Loading signal processor...",
            "Loading radio interface...",
            "Checking microphone interface...",
            "Checking waveform monitor...",
            "Initializing export subsystem...",
            "Loading station identification...",
            "Verifying frequency table..."
        ]
        self.done_lines = []
        self.current = 0
        self.spinner = 0
        self.text = QLabel()
        self.text.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.text.setStyleSheet(
            "font-family:Consolas,monospace;font-size:16px;color:#00ff00;"
            "padding:18px;"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12)
        lay.addWidget(self.text)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(170)

    def tick(self):
        chars = ["\\", "|", "/", "-"]
        self.spinner = (self.spinner + 1) % len(chars)
        if self.current < len(self.lines):
            line = self.lines[self.current]
            if self.current == 0:
                self.done_lines.append(line)
                self.current += 1
            else:
                self.done_lines.append(f"{line:<48} [OK]")
                self.current += 1
        else:
            self.done_lines.append("")
            self.done_lines.append("TREDT Typewriter changed to TREDT Radio Station")
            self.done_lines.append("")
            self.done_lines.append("BOOT COMPLETE.")
            self.done_lines.append("Launching terminal...")
            self.timer.stop()
            self.text.setText("\n".join(self.done_lines))
            QTimer.singleShot(1200, self.finished.emit)
            return

        active = f"  {chars[self.spinner]}  SYSTEM ACTIVITY"
        self.text.setText("\n".join(self.done_lines) + "\n" + active)

class DialupConsole(QWidget):
    finished = Signal()

    def __init__(self):
        super().__init__()
        self.resize(900, 560)
        self.setStyleSheet("background:#000;color:#00ff00;")
        self.elapsed = 0
        self.spinner = 0
        self.title = QLabel("TREDT RADIO COMMUNICATIONS TERMINAL")
        self.title.setStyleSheet("font:700 18px Consolas;color:#00ff00;")
        self.output = QLabel()
        self.output.setStyleSheet("font:15px Consolas;color:#00ff00;")
        self.output.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.answer = QComboBox()
        self.answer.addItems(["Y","N"])
        self.enter = QPushButton("ENTER")
        self.enter.clicked.connect(self.begin)
        lay = QVBoxLayout(self)
        lay.addWidget(self.title)
        lay.addWidget(self.output, 1)
        row = QHBoxLayout()
        row.addWidget(QLabel("CONNECT TO RADIO STATION (Y/N):"))
        row.addWidget(self.answer)
        row.addWidget(self.enter)
        lay.addLayout(row)
        self.render_prompt()

    def render_prompt(self):
        self.output.setText(
            "----------------------------------------\n\n"
            "Would you like to connect to the Radio Station (Y/N):"
        )

    def begin(self):
        if self.answer.currentText() == "N":
            self.finished.emit()
            return
        self.answer.setEnabled(False)
        self.enter.setEnabled(False)
        self.elapsed = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.step)
        self.timer.start(1000)
        self.step()

    def step(self):
        self.elapsed += 1
        spinner = ["\\","|","/","-"][self.elapsed % 4]
        stages = [
            "INITIALIZING MODEM",
            "DIALING 876.43 MHz",
            "DIAL TONE DETECTED",
            "CARRIER DETECTED",
            "HANDSHAKE",
            "NEGOTIATING TREDT-RADIO/1.0",
            "SYNCHRONIZING AUDIO CHANNEL",
            "LOCKING SIGNAL",
            "VERIFYING STATION",
            "CONNECTION SUCCESSFUL"
        ]
        stage = stages[min(len(stages)-1, (self.elapsed-1)//2)]
        bars = "█" * min(20, int(self.elapsed/15*20))
        self.output.setText(
            "----------------------------------------\n"
            "TREDT RADIO COMMUNICATIONS TERMINAL\n\n"
            f"> ATZ\n> OK\n> ATDT {FREQUENCY}\n\n"
            f"{stage:<36} {spinner}\n"
            f"SIGNAL [{bars:<20}] {self.elapsed:02d}/15 SEC\n\n"
            f"FREQUENCY : {FREQUENCY}\n"
            "CHANNEL   : PRIMARY AUDIO"
        )
        if self.elapsed >= 15:
            self.timer.stop()
            QTimer.singleShot(700, self.finished.emit)

class Waveform(QWidget):
    def __init__(self):
        super().__init__()
        self.samples = np.zeros(800, np.float32)
        self.bg="#000000"; self.fg="#00ff00"; self.grid="#008000"; self.accent="#00ff00"
        self.setMinimumHeight(270)

    def colors(self,bg,fg,grid,accent):
        self.bg,self.fg,self.grid,self.accent=bg,fg,grid,accent
        self.update()

    def set_samples(self,s):
        if len(s):
            self.samples=np.asarray(s,np.float32)
        self.update()

    def paintEvent(self,e):
        p=QPainter(self)
        p.fillRect(self.rect(),QColor(self.bg))
        w,h=self.width(),self.height()
        # technical grid
        gp=QPen(QColor(self.grid)); gp.setWidth(1); p.setPen(gp)
        for y in [0.16,.33,.5,.67,.84]:
            p.drawLine(0,int(h*y),w,int(h*y))
        for x in range(0,w,80):
            p.drawLine(x,0,x,h)
        # center line
        ap=QPen(QColor(self.accent)); ap.setWidth(1); p.setPen(ap)
        p.drawLine(0,h//2,w,h//2)
        # labels
        p.setFont(QFont("Consolas",8))
        for label,y in [("0 dB",.16),("-12 dB",.33),("-24 dB",.50),("-36 dB",.67),("-48 dB",.84)]:
            p.drawText(5,int(h*y)-3,label)
        # waveform
        wp=QPen(QColor(self.fg)); wp.setWidth(2); p.setPen(wp)
        arr=self.samples
        step=max(1,len(arr)//max(1,w))
        pts=arr[::step][:w]
        mid=h/2; scale=h*.31
        lx,ly=0,mid
        for i,v in enumerate(pts):
            x=i; y=mid-float(v)*scale
            p.drawLine(lx,int(ly),x,int(y))
            lx,ly=x,y

class Spectrum(QWidget):
    """Small frequency display for the console's signal monitor."""
    def __init__(self):
        super().__init__()
        self.samples = np.zeros(1024, np.float32)
        self.fg = "#00ff00"; self.grid = "#008000"; self.bg = "#000000"
        self.setMinimumHeight(115)

    def colors(self, bg, fg, grid):
        self.bg, self.fg, self.grid = bg, fg, grid
        self.update()

    def set_samples(self, samples):
        if len(samples): self.samples = np.asarray(samples, np.float32)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.fillRect(self.rect(), QColor(self.bg))
        w, h = self.width(), self.height()
        p.setPen(QPen(QColor(self.grid)))
        p.drawLine(0, h - 20, w, h - 20)
        p.setFont(QFont("Consolas", 8)); p.setPen(QColor(self.fg))
        for pos, text in zip((0.02, .30, .57, .82), ("856", "866", "876", "886")):
            p.drawText(int(w * pos), h - 4, text)
        data = self.samples
        if len(data) < 8: return
        bins = np.abs(np.fft.rfft(data * np.hanning(len(data))))
        bins = bins[1:min(len(bins), 100)]
        if not len(bins): return
        count = 28
        ix = np.linspace(0, len(bins) - 1, count).astype(int)
        values = bins[ix]; values /= max(float(values.max()), 1e-9)
        gap = max(2, w // (count * 2)); bar = max(2, gap - 2)
        base = h - 22
        p.setBrush(QColor(self.fg)); p.setPen(Qt.NoPen)
        for i, value in enumerate(values):
            height = max(3, int(value * (h - 43)))
            x = int((i + .5) * w / count)
            p.drawRect(x, base - height, bar, height)

class RadioStation(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1100,700)
        self.bg="#000000"; self.fg="#00ff00"; self.graph="#00ff00"; self.grid="#008000"; self.accent="#00ff00"
        self.theme_mode="original"
        self.recording=False; self.paused=False; self.playing=False; self.frames=0
        self.chunks=[]; self.current=np.zeros(1024,np.float32)
        self.build()
        self.apply_theme()
        self.ui=QTimer(self); self.ui.timeout.connect(self.refresh); self.ui.start(60)

    def build(self):
        mb=self.menuBar()
        filem=mb.addMenu("FILE"); edit=mb.addMenu("EDIT"); select=mb.addMenu("SELECT")
        view=mb.addMenu("VIEW"); transport=mb.addMenu("TRANSPORT"); tracks=mb.addMenu("TRACKS")
        generate=mb.addMenu("GENERATE"); effect=mb.addMenu("EFFECT"); analyze=mb.addMenu("ANALYZE")
        tools=mb.addMenu("TOOLS"); helpm=mb.addMenu("HELP")
        filem.addAction("NEW RECORDING",self.new_recording); filem.addAction("EXPORT MP3",self.export); filem.addSeparator(); filem.addAction("EXIT",self.close)
        edit.addAction("CLEAR RECORDING", self.new_recording)
        select.addAction("SELECT ALL", self.select_all)
        view.addAction("RESET DISPLAY", self.reset_display)
        transport.addAction("PLAY", self.play); transport.addAction("PAUSE / RESUME",self.pause)
        transport.addAction("STOP",self.stop); transport.addAction("RECORD",self.start)
        tracks.addAction("MONO INPUT", lambda: None)
        generate.addAction("MORSE STATION ID", self.show_morse_info)
        effect.addAction("OLD RADIO PROCESSING", self.show_effect_info)
        analyze.addAction("SIGNAL MONITOR", self.reset_display)
        tools.addAction("COLOR CONFIGURATION", self.color_config)
        helpm.addAction("ABOUT",self.about)

        central=QWidget(); self.setCentralWidget(central)
        root=QVBoxLayout(central); root.setContentsMargins(10,8,10,8); root.setSpacing(6)

        header=QFrame(); header.setFrameShape(QFrame.Box)
        hg=QGridLayout(header); hg.setContentsMargins(12,6,12,6)
        self.station=QLabel("TREDT RADIO STATION")
        self.station.setStyleSheet("font:700 21px Consolas;")
        self.freq=QLabel(FREQUENCY); self.freq.setStyleSheet("font:700 21px Consolas;")
        self.channel=QLabel("RX LEVEL  ▮▮▮▮▮▮▮▮▮▮▮▮   -42 dB")
        self.channel.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        hg.addWidget(self.station,0,0); hg.addWidget(self.freq,0,1); hg.addWidget(self.channel,0,2)
        self.mode=QLabel("MODE: STANDBY")
        self.clock=QLabel(); self.clock.setAlignment(Qt.AlignRight)
        hg.addWidget(self.mode, 1, 0, 1, 2); hg.addWidget(self.clock, 1, 2)
        root.addWidget(header)

        panels=QHBoxLayout(); panels.setSpacing(8)
        terminal=QFrame(); terminal.setFrameShape(QFrame.Box); tl=QVBoxLayout(terminal); tl.setContentsMargins(12,10,12,8)
        term_title=QLabel("> SYSTEM TERMINAL                         \\ | / -")
        term_title.setStyleSheet("font:700 16px Consolas;")
        tl.addWidget(term_title)
        self.terminal_text=QLabel(
            "Starting TREDT RADIO STATION...                 [OK]\n"
            "Loading DOS compatibility layer...             [OK]\n"
            "Initializing audio engine...                    [OK]\n"
            "Loading signal processor...                    [OK]\n"
            "Calibrating input device...                    [OK]\n"
            "Loading radio interface...                     [OK]\n"
            "Verifying frequency table...                   [OK]\n\n"
            "BOOT COMPLETE.\nLaunching terminal...\n\nC:\\TREDT-RADIO\\>_")
        self.terminal_text.setAlignment(Qt.AlignLeft | Qt.AlignTop); self.terminal_text.setStyleSheet("font:15px Consolas;")
        tl.addWidget(self.terminal_text, 1)
        panels.addWidget(terminal, 1)

        monitor=QFrame(); monitor.setFrameShape(QFrame.Box); ml=QVBoxLayout(monitor); ml.setContentsMargins(10,10,10,8); ml.setSpacing(5)
        sig=QLabel("> SIGNAL MONITOR"); sig.setStyleSheet("font:700 16px Consolas;"); ml.addWidget(sig)
        self.wave=Waveform(); self.wave.setMinimumHeight(245); ml.addWidget(self.wave, 1)
        lower=QHBoxLayout(); stats=QLabel("FREQUENCY : 876.43 MHz\nBANDWIDTH : 20.00 kHz\nMODE      : MONO FM\nSNR       : 38.7 dB\nSIGNAL    : STABLE")
        stats.setStyleSheet("font:14px Consolas;"); lower.addWidget(stats, 1)
        spectrum_frame=QFrame(); sl=QVBoxLayout(spectrum_frame); sl.setContentsMargins(7,5,7,2); sl.addWidget(QLabel("> SPECTRUM")); self.spectrum=Spectrum(); sl.addWidget(self.spectrum); lower.addWidget(spectrum_frame, 1)
        ml.addLayout(lower); panels.addWidget(monitor, 1)
        root.addLayout(panels, 1)

        info=QFrame(); info.setFrameShape(QFrame.Box)
        g=QGridLayout(info); g.setContentsMargins(12,8,12,8); g.setHorizontalSpacing(14); g.setVerticalSpacing(3)
        fields=[("STATUS","status"),("SAMPLE RATE","rate"),("RECORDING TIME","duration"),("RECORDING","recording"),("BIT DEPTH","depth"),("FILE SIZE","size"),("INPUT SOURCE","input"),("CHANNELS","channels"),("DISK SPACE","disk"),("AUDIO FILTER","filter"),("ENCODER","encoder"),("LOCATION","location")]
        self.labels={}
        for i,(name,key) in enumerate(fields):
            col=(i%3)*3; row=(i//3)*2
            lab=QLabel(name); val=QLabel(""); self.labels[key]=val
            g.addWidget(lab,row,col); g.addWidget(QLabel(":"),row,col+1); g.addWidget(val,row,col+2)
        root.addWidget(info)

        controls=QFrame(); controls.setFrameShape(QFrame.Box)
        cg=QHBoxLayout(controls); cg.setContentsMargins(6,4,6,4)
        for txt,fn in [("● RECORD",self.start),("▶ PLAY",self.play),("Ⅱ PAUSE",self.pause),("■ STOP",self.stop),("♫ EXPORT MP3",self.export),("🎨 THEME",self.theme)]:
            b=QPushButton(txt); b.clicked.connect(fn); cg.addWidget(b)
        root.addWidget(controls)

        toolbar=QFrame(); toolbar.setFrameShape(QFrame.Box); tb=QHBoxLayout(toolbar); tb.setContentsMargins(8,3,8,3)
        tb.addWidget(QLabel("TEMPO")); self.tempo=QLineEdit("120"); self.tempo.setMaximumWidth(52); tb.addWidget(self.tempo)
        tb.addWidget(QLabel("TIME SIGNATURE")); self.signature=QLineEdit("4 / 4"); self.signature.setMaximumWidth(60); tb.addWidget(self.signature)
        self.snap=QCheckBox("SNAP"); self.snap.setChecked(True); tb.addWidget(self.snap)
        tb.addWidget(QLabel("AUDIO POSITION")); self.position=QLineEdit("00 h 00 m 00.000 s"); self.position.setMaximumWidth(155); tb.addWidget(self.position)
        tb.addWidget(QLabel("SELECTION")); self.selection=QLineEdit("00 h 00 m 00.000 s"); self.selection.setMaximumWidth(155); tb.addWidget(self.selection); tb.addStretch()
        root.addWidget(toolbar)

        footer=QLabel("TREDT-RADIO/1.1       TERMINAL ID: TRS876-TERMINAL-01       SECURE LINK: ESTABLISHED")
        footer.setAlignment(Qt.AlignCenter); root.addWidget(footer)

    def apply_theme(self):
        if self.theme_mode == "nt4":
            self.setStyleSheet("""
            QMainWindow,QWidget{background:#C0C0C0;color:#000000;}
            QLabel,QCheckBox{color:#000000;font-family:'MS Sans Serif',Tahoma,Arial;}
            QMenuBar{background:#C0C0C0;color:#000000;border-bottom:1px solid #808080;font-family:'MS Sans Serif',Tahoma;}
            QMenu{background:#C0C0C0;color:#000000;border:2px outset #DFDFDF;font-family:'MS Sans Serif',Tahoma;}
            QLineEdit,QComboBox{background:#FFFFFF;color:#000000;border:2px inset #DFDFDF;font-family:'MS Sans Serif',Tahoma;}
            QPushButton{background:#C0C0C0;color:#000000;border:2px outset #DFDFDF;font:700 13px 'MS Sans Serif',Tahoma;padding:7px 12px;min-height:25px;}
            QPushButton:pressed{border:2px inset #DFDFDF;}
            QFrame{border:2px outset #DFDFDF;}
            """)
            self.wave.colors("#FFFFFF", "#000080", "#808080", "#000080")
            self.spectrum.colors("#FFFFFF", "#000080", "#808080")
            return
        self.setStyleSheet(f"""
        QMainWindow,QWidget{{background:{self.bg};color:{self.fg};}}
        QLabel{{color:{self.fg};font-family:Consolas,monospace;}}
        QMenuBar,QMenu,QComboBox,QLineEdit{{background:{self.bg};color:{self.fg};border:1px solid {self.fg};font-family:Consolas;}}
        QPushButton{{background:{self.fg};color:{self.bg};border:1px solid {self.fg};font:700 15px Consolas;padding:12px 16px;min-height:28px;}}
        QPushButton:hover{{background:{self.accent};}}
        QCheckBox{{font-family:Consolas;color:{self.fg};}}
        QFrame{{border:1px solid {self.grid};}}
        """)
        self.wave.colors(self.bg,self.graph,self.grid,self.accent)
        self.spectrum.colors(self.bg, self.graph, self.grid)

    def start(self):
        if self.recording: return
        if self.playing: self.stop()
        try:
            self.recording=True; self.paused=False
            self.mode.setText("MODE: RECORDING")
            if not self.chunks: self.started=time.time()
            self.stream=sd.InputStream(samplerate=SAMPLE_RATE,channels=1,dtype="float32",blocksize=1024,callback=self.audio)
            self.stream.start()
        except Exception as e:
            self.recording=False
            QMessageBox.critical(self,"MICROPHONE ERROR",str(e))

    def audio(self,indata,frames,time_info,status):
        self.current=indata[:,0].copy()
        if self.recording and not self.paused:
            self.chunks.append(self.current.copy()); self.frames+=len(self.current)

    def pause(self):
        if self.recording:
            self.paused=not self.paused
            self.mode.setText("MODE: PAUSED" if self.paused else "MODE: RECORDING")

    def stop(self):
        if self.playing:
            sd.stop(); self.playing=False
        if hasattr(self,"stream"):
            try:self.stream.stop();self.stream.close()
            except:pass
            try:del self.stream
            except:pass
        if self.recording:
            self.recording=False; self.paused=False; self.mode.setText("MODE: STOPPED")

    def play(self):
        if self.recording:
            self.pause()
            return
        if not self.chunks:
            QMessageBox.information(self, "PLAYBACK", "No recording available.")
            return
        try:
            self.playing = True
            self.mode.setText("MODE: PLAYBACK")
            sd.play(np.concatenate(self.chunks), SAMPLE_RATE, blocking=False)
        except Exception as e:
            self.playing = False
            QMessageBox.critical(self, "PLAYBACK ERROR", str(e))

    def select_all(self):
        duration = self.frames / SAMPLE_RATE
        self.selection.setText(f"00 h {int(duration // 60):02d} m {duration % 60:06.3f} s")

    def reset_display(self):
        self.position.setText("00 h 00 m 00.000 s")
        self.selection.setText("00 h 00 m 00.000 s")

    def show_morse_info(self):
        QMessageBox.information(self, "MORSE STATION ID", "Every exported MP3 starts with the mandatory TREDT station ID in Morse code.")

    def show_effect_info(self):
        QMessageBox.information(self, "OLD RADIO PROCESSING", "Old-radio filtering, compression, hiss, and crackle are applied during MP3 export.")

    def new_recording(self):
        self.stop(); self.chunks=[]; self.frames=0; self.current=np.zeros(1024,np.float32)

    def refresh(self):
        now=datetime.now()
        self.clock.setText(now.strftime("%d/%m/%Y  %H:%M:%S"))
        self.labels["status"].setText("RECORDING" if self.recording and not self.paused else ("PAUSED" if self.paused else "STOPPED"))
        secs=self.frames/SAMPLE_RATE
        h=int(secs//3600); m=int((secs%3600)//60); s=int(secs%60); ms=int((secs-int(secs))*1000)
        self.labels["duration"].setText(f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}")
        self.labels["size"].setText(self.hsize(self.frames*2))
        self.labels["rate"].setText("44,100 Hz / MONO")
        self.labels["recording"].setText("ACTIVE" if self.recording else "STOPPED")
        self.labels["depth"].setText("16-bit")
        self.labels["input"].setText("MICROPHONE (REAL)")
        self.labels["channels"].setText("1 (MONO)")
        self.labels["disk"].setText("AVAILABLE")
        self.labels["filter"].setText("OLD RADIO")
        self.labels["encoder"].setText("MP3 (LAME)")
        self.labels["location"].setText("recordings\\")
        rms=float(np.sqrt(np.mean(self.current**2))) if len(self.current) else 0
        db=20*math.log10(max(rms,1e-7))
        bars = "▮" * max(0, min(12, int((db + 72) / 4)))
        self.channel.setText(f"RX LEVEL  {bars:<12}  {db:6.1f} dB")
        self.wave.set_samples(self.current)
        self.spectrum.set_samples(self.current)
        secs = self.frames / SAMPLE_RATE
        self.position.setText(f"{int(secs//3600):02d} h {int(secs%3600//60):02d} m {secs%60:06.3f} s")

    @staticmethod
    def hsize(n):
        x=float(n); units=["B","KB","MB","GB"]; u=0
        while x>=1024 and u<3:x/=1024;u+=1
        return f"{x:.2f} {units[u]}"

    def original_theme(self):
        self.theme_mode="original"
        self.bg="#000000"; self.fg="#00ff00"; self.graph="#00ff00"; self.grid="#008000"; self.accent="#00ff00"
        self.apply_theme()

    def nt4_theme(self):
        self.theme_mode="nt4"
        self.apply_theme()

    def theme(self):
        d=QDialog(self); d.setWindowTitle("TREDT THEME")
        lay=QVBoxLayout(d); lay.addWidget(QLabel("SELECT CONSOLE THEME"))
        original=QPushButton("ORIGINAL")
        nt4=QPushButton("WINDOWS 4 NT")
        colors=QPushButton("COLOR CONFIGURATION")
        lay.addWidget(original); lay.addWidget(nt4); lay.addWidget(colors)
        original.clicked.connect(lambda: (self.original_theme(), d.accept()))
        nt4.clicked.connect(lambda: (self.nt4_theme(), d.accept()))
        colors.clicked.connect(lambda: (d.accept(), self.color_config()))
        d.exec()

    def color_config(self):
        d=QDialog(self); d.setWindowTitle("TREDT COLOR CONFIGURATION")
        g=QGridLayout(d); boxes=[]
        for row,name,current in [(0,"BACKGROUND",self.bg),(1,"TEXT",self.fg),(2,"WAVEFORM",self.graph),(3,"GRID",self.grid),(4,"ACCENT",self.accent)]:
            b=QComboBox()
            for n,h in PALETTE:b.addItem(n,h)
            for i in range(b.count()):
                if b.itemData(i).upper()==current.upper():b.setCurrentIndex(i)
            g.addWidget(QLabel(name),row,0);g.addWidget(b,row,1);boxes.append(b)
        ok=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);g.addWidget(ok,5,0,1,2)
        ok.accepted.connect(d.accept);ok.rejected.connect(d.reject)
        if d.exec():
            self.bg,self.fg,self.graph,self.grid,self.accent=[b.currentData() for b in boxes]
            self.theme_mode="original"
            self.apply_theme()

    def export(self):
        self.stop()
        if not self.chunks:
            QMessageBox.information(self,"EXPORT","No recording available.");return
        if shutil.which("ffmpeg") is None:
            QMessageBox.critical(self,"FFMPEG REQUIRED","FFmpeg was not found on PATH.");return
        voice=radio_process(np.concatenate(self.chunks))
        final=np.concatenate([morse_audio(),np.zeros(int(.12*SAMPLE_RATE),np.float32),voice])
        default=Path("recordings")/f"TREDT_RADIO_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
        path,_=__import__("PySide6.QtWidgets",fromlist=["QFileDialog"]).QFileDialog.getSaveFileName(self,"EXPORT MP3",str(default),"MP3 Audio (*.mp3)")
        if not path:return
        with tempfile.TemporaryDirectory() as td:
            wav=Path(td)/"final.wav";sf.write(wav,final,SAMPLE_RATE,subtype="PCM_16")
            try:
                subprocess.run(["ffmpeg","-y","-loglevel","error","-i",str(wav),"-codec:a","libmp3lame","-b:a","192k",path],check=True)
            except Exception as e:
                QMessageBox.critical(self,"EXPORT ERROR",str(e));return
        QMessageBox.information(self,"EXPORT COMPLETE",f"Saved:\n{path}\n\nTREDT Morse station ID attached.")

    def about(self):
        QMessageBox.information(self,"TREDT RADIO STATION",
            "TREDT RADIO STATION v1.1\n\n876.43 MHz\nTREDT-RADIO/1.0\n\n"
            "Mandatory station ID:\nTREDT RADIO STATION 876.43 MHz\n"
            "Morse: 20 WPM / 550 Hz / 15% volume")

def main():
    app=QApplication(sys.argv)
    boot=BootConsole()
    boot.show()
    def terminal():
        boot.close()
        d=DialupConsole();d.show()
        def station():
            d.close(); w=RadioStation();w.show();app._station=w
        d.finished.connect(station);app._dial=d
    boot.finished.connect(terminal)
    return app.exec()

if __name__=="__main__":
    sys.exit(main())
