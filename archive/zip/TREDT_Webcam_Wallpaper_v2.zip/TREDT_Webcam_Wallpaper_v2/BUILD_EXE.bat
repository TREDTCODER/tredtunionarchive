@echo off
title Build TREDT Webcam Wallpaper
py -m pip install PySide6 opencv-python pyinstaller
py -m PyInstaller --clean --onefile --windowed --name "TREDT Webcam Wallpaper" TREDT_Webcam_Wallpaper.py
echo.
echo Build complete. Check the dist folder.
pause
