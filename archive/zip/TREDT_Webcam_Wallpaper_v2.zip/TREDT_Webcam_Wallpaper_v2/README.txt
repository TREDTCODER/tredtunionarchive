# TREDT Webcam Wallpaper

Windows desktop wallpaper application using a live webcam feed.

## Features

- Live webcam as desktop wallpaper
- Desktop icons remain visible/interactable
- Taskbar and Start menu remain normal Explorer UI
- All-monitor or selected-monitor wallpaper
- 10–60 FPS
- Low / Medium / High quality
- Optional mirrored camera
- Camera refresh/discovery
- Lightweight preview
- Optional fullscreen-app/game pause
- TREDT-style dark control panel

## Install

PowerShell:

    py -m pip install PySide6 opencv-python

## Run

    py TREDT_Webcam_Wallpaper.py

## Build EXE

    py -m pip install pyinstaller
    py -m PyInstaller --onefile --windowed --name "TREDT Webcam Wallpaper" TREDT_Webcam_Wallpaper.py

The EXE will be in:

    dist\TREDT Webcam Wallpaper.exe

## Notes

Windows Explorer owns the desktop icon layer. The application uses the
WorkerW desktop layer so the webcam renderer sits behind the icons.

Some Windows Explorer/custom-shell configurations may recreate WorkerW.
If that happens, restarting Explorer or restarting the application restores
the wallpaper layer.

The "Start automatically with Windows" checkbox is included in the UI
foundation, but this source version does not yet modify the Windows startup
registry automatically.
