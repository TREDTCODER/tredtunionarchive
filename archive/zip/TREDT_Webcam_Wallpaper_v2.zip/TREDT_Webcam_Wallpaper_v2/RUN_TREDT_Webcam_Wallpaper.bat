@echo off
title TREDT Webcam Wallpaper
py -m pip install PySide6 opencv-python
py TREDT_Webcam_Wallpaper.py
pause
