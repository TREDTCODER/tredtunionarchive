import sys
import ctypes
import cv2
import time
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QImage, QPixmap, QFont
from PySide6.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QComboBox, QSpinBox, QCheckBox, QGroupBox,
    QMessageBox, QSlider, QFrame
)

user32 = ctypes.windll.user32

# ---------------- Windows desktop integration ----------------

WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_long)

def find_workerw():
    progman = user32.FindWindowW("Progman", None)
    if not progman:
        raise RuntimeError("Windows desktop (Progman) could not be found.")

    user32.SendMessageTimeoutW(
        progman, 0x052C, 0, 0, 0x0000, 1000, None
    )

    result = {"hwnd": 0}

    def enum_proc(hwnd, lparam):
        shell = user32.FindWindowExW(hwnd, 0, "SHELLDLL_DefView", None)
        if shell:
            w = user32.FindWindowExW(0, hwnd, "WorkerW", None)
            if w:
                result["hwnd"] = w
        return True

    user32.EnumWindows(WNDENUMPROC(enum_proc), 0)
    return result["hwnd"] or progman

def set_wallpaper_parent(hwnd, parent):
    user32.SetParent(hwnd, parent)

    # WS_CHILD + WS_VISIBLE; remove border/caption.
    style = user32.GetWindowLongW(hwnd, -16)
    style &= ~0x00C00000
    style &= ~0x00040000
    style |= 0x40000000 | 0x10000000
    user32.SetWindowLongW(hwnd, -16, style)

    user32.SetWindowPos(
        hwnd, 0, 0, 0, 0, 0,
        0x0001 | 0x0002 | 0x0010 | 0x0040
    )

# ---------------- Webcam renderer ----------------

class CameraLayer(QWidget):
    def __init__(self, camera_index, fps, quality, mirror=False):
        super().__init__()
        self.camera_index = camera_index
        self.target_fps = fps
        self.quality = quality
        self.mirror = mirror
        self.capture = None

        self.label = QLabel()
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("background:#000;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.label)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)

    def start(self):
        self.capture = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
        if not self.capture.isOpened():
            self.capture = cv2.VideoCapture(self.camera_index)
        if not self.capture.isOpened():
            raise RuntimeError(f"Could not open camera {self.camera_index}.")

        # Request a common webcam mode; the driver may choose another mode.
        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
        self.capture.set(cv2.CAP_PROP_FPS, self.target_fps)

        self.timer.start(max(1, int(1000 / self.target_fps)))

    def stop(self):
        self.timer.stop()
        if self.capture:
            self.capture.release()
            self.capture = None
        self.label.clear()

    def next_frame(self):
        if not self.capture:
            return

        ok, frame = self.capture.read()
        if not ok:
            return

        if self.mirror:
            frame = cv2.flip(frame, 1)

        h, w = frame.shape[:2]
        tw, th = self.width(), self.height()
        if tw <= 0 or th <= 0:
            return

        # Quality controls how aggressively the source is reduced before scaling.
        if self.quality == "Low":
            max_w = 960
        elif self.quality == "Medium":
            max_w = 1280
        else:
            max_w = 1920

        if w > max_w:
            ratio = max_w / w
            frame = cv2.resize(
                frame, (int(w * ratio), int(h * ratio)),
                interpolation=cv2.INTER_AREA
            )

        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w = frame.shape[:2]
        source_ratio = w / h
        target_ratio = tw / th

        # Fill without distortion.
        if source_ratio > target_ratio:
            crop_w = int(h * target_ratio)
            x = max(0, (w - crop_w) // 2)
            frame = frame[:, x:x + crop_w]
        else:
            crop_h = int(w / target_ratio)
            y = max(0, (h - crop_h) // 2)
            frame = frame[y:y + crop_h, :]

        frame = cv2.resize(frame, (tw, th), interpolation=cv2.INTER_LINEAR)

        image = QImage(
            frame.data, tw, th, tw * 3, QImage.Format_RGB888
        ).copy()
        self.label.setPixmap(QPixmap.fromImage(image))

# ---------------- Controller ----------------

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.layers = []
        self.paused_for_fullscreen = False
        self.last_activity = time.monotonic()

        self.setWindowTitle("TREDT Webcam Wallpaper")
        self.resize(500, 650)
        self.build_ui()
        self.detect_cameras()

        self.fullscreen_timer = QTimer(self)
        self.fullscreen_timer.timeout.connect(self.check_fullscreen)
        self.fullscreen_timer.start(1500)

    def build_ui(self):
        self.setStyleSheet("""
            QWidget { background:#111; color:#eee; font-family:Segoe UI; }
            QGroupBox { border:1px solid #444; margin-top:10px; padding:12px; }
            QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; }
            QPushButton { background:#222; border:1px solid #666; padding:9px; }
            QPushButton:hover { background:#333; }
            QComboBox, QSpinBox { background:#1d1d1d; border:1px solid #555; padding:7px; }
            QCheckBox { padding:5px; }
        """)

        main = QVBoxLayout(self)

        title = QLabel("TREDT WEBCAM WALLPAPER")
        title.setFont(QFont("Consolas", 20, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        main.addWidget(title)

        subtitle = QLabel("LIVE DESKTOP CAMERA SYSTEM")
        subtitle.setAlignment(Qt.AlignCenter)
        main.addWidget(subtitle)

        cam = QGroupBox("CAMERA")
        cl = QVBoxLayout(cam)

        row = QHBoxLayout()
        row.addWidget(QLabel("Device:"))
        self.camera = QComboBox()
        row.addWidget(self.camera, 1)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.detect_cameras)
        row.addWidget(refresh)
        cl.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("FPS:"))
        self.fps = QSpinBox()
        self.fps.setRange(10, 60)
        self.fps.setValue(30)
        row.addWidget(self.fps)

        row.addWidget(QLabel("Quality:"))
        self.quality = QComboBox()
        self.quality.addItems(["Low", "Medium", "High"])
        self.quality.setCurrentText("High")
        row.addWidget(self.quality)
        cl.addLayout(row)

        self.mirror = QCheckBox("Mirror camera")
        cl.addWidget(self.mirror)
        main.addWidget(cam)

        disp = QGroupBox("DISPLAY")
        dl = QVBoxLayout(disp)

        row = QHBoxLayout()
        row.addWidget(QLabel("Wallpaper screens:"))
        self.monitor = QComboBox()
        self.monitor.addItem("All monitors", -1)
        dl.addLayout(row)
        row.addWidget(self.monitor)
        self.monitor.currentIndexChanged.connect(self.update_monitor_mode)

        self.game_pause = QCheckBox("Pause wallpaper while a fullscreen app/game is active")
        self.game_pause.setChecked(True)
        dl.addWidget(self.game_pause)

        self.startup = QCheckBox("Start wallpaper automatically with Windows")
        dl.addWidget(self.startup)

        main.addWidget(disp)

        preview_box = QGroupBox("PREVIEW")
        pl = QVBoxLayout(preview_box)
        self.preview = QLabel("Camera preview appears here")
        self.preview.setMinimumHeight(180)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet("background:#050505; border:1px solid #444;")
        pl.addWidget(self.preview)
        main.addWidget(preview_box)

        controls = QHBoxLayout()
        self.apply_btn = QPushButton("APPLY WALLPAPER")
        self.apply_btn.clicked.connect(self.start_wallpaper)
        controls.addWidget(self.apply_btn)

        self.stop_btn = QPushButton("STOP")
        self.stop_btn.clicked.connect(self.stop_wallpaper)
        controls.addWidget(self.stop_btn)
        main.addLayout(controls)

        self.status = QLabel("STATUS: STOPPED")
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
        main.addWidget(self.status)

        note = QLabel(
            "Desktop icons remain above the wallpaper layer.\n"
            "The taskbar and Start menu remain normal Windows Explorer UI."
        )
        note.setAlignment(Qt.AlignCenter)
        main.addWidget(note)

        self.preview_timer = QTimer(self)
        self.preview_timer.timeout.connect(self.update_preview)
        self.preview_timer.start(100)

    def detect_cameras(self):
        current = self.camera.currentData() if self.camera.count() else None
        self.camera.clear()

        found = 0
        for i in range(10):
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if cap.isOpened():
                self.camera.addItem(f"Camera {i}", i)
                found += 1
                cap.release()

        if found == 0:
            self.camera.addItem("No camera detected", -1)
        elif current is not None:
            idx = self.camera.findData(current)
            if idx >= 0:
                self.camera.setCurrentIndex(idx)

        self.monitor.clear()
        self.monitor.addItem("All monitors", -1)
        for i, screen in enumerate(QApplication.screens(), 1):
            self.monitor.addItem(
                f"Monitor {i}: {screen.name()} "
                f"({screen.geometry().width()}×{screen.geometry().height()})",
                i - 1
            )

    def update_monitor_mode(self):
        pass

    def update_preview(self):
        # Preview is intentionally lightweight and independent of the wallpaper.
        # It is only active while the control panel is visible.
        if not self.layers:
            idx = self.camera.currentData()
            if idx is None or idx < 0:
                return
            # Avoid opening a second persistent camera when wallpaper is running.
            if not hasattr(self, "_preview_cap") or self._preview_cap is None:
                self._preview_cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
            if not self._preview_cap.isOpened():
                return
            ok, frame = self._preview_cap.read()
            if not ok:
                return
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w = frame.shape[:2]
            pw, ph = self.preview.width(), self.preview.height()
            frame = cv2.resize(frame, (max(1, pw), max(1, ph)))
            image = QImage(frame.data, pw, ph, pw * 3, QImage.Format_RGB888).copy()
            self.preview.setPixmap(QPixmap.fromImage(image))

    def close_preview_camera(self):
        cap = getattr(self, "_preview_cap", None)
        if cap:
            cap.release()
            self._preview_cap = None

    def start_wallpaper(self):
        idx = self.camera.currentData()
        if idx is None or idx < 0:
            QMessageBox.warning(self, "Camera", "No usable webcam was detected.")
            return

        self.close_preview_camera()
        self.stop_wallpaper()

        screens = QApplication.screens()
        selected = self.monitor.currentData()

        if selected is None or selected == -1:
            target_screens = screens
        elif 0 <= selected < len(screens):
            target_screens = [screens[selected]]
        else:
            target_screens = screens

        try:
            parent = find_workerw()

            for screen in target_screens:
                layer = CameraLayer(
                    idx,
                    self.fps.value(),
                    self.quality.currentText(),
                    self.mirror.isChecked()
                )
                layer.setGeometry(screen.geometry())
                layer.show()
                QApplication.processEvents()

                set_wallpaper_parent(int(layer.winId()), parent)
                layer.setGeometry(screen.geometry())
                layer.show()
                layer.start()

                self.layers.append(layer)

            self.status.setText(
                f"STATUS: LIVE — {len(self.layers)} MONITOR(S)"
            )

        except Exception as exc:
            self.stop_wallpaper()
            QMessageBox.critical(self, "Wallpaper Error", str(exc))

    def stop_wallpaper(self):
        self.close_preview_camera()

        for layer in self.layers:
            layer.stop()
            layer.setParent(None)
            layer.close()
            layer.deleteLater()

        self.layers.clear()
        self.status.setText("STATUS: STOPPED")

    def check_fullscreen(self):
        if not self.game_pause.isChecked() or not self.layers:
            return

        # Conservative fullscreen detection: foreground window bounds.
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return

        rect = ctypes.wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return

        sw = user32.GetSystemMetrics(0)
        sh = user32.GetSystemMetrics(1)

        fullscreen = (
            rect.left <= 0 and rect.top <= 0 and
            rect.right >= sw and rect.bottom >= sh
        )

        if fullscreen and not self.paused_for_fullscreen:
            for layer in self.layers:
                layer.timer.stop()
            self.paused_for_fullscreen = True
            self.status.setText("STATUS: PAUSED — FULLSCREEN APP")
        elif not fullscreen and self.paused_for_fullscreen:
            for layer in self.layers:
                layer.timer.start(max(1, int(1000 / layer.target_fps)))
            self.paused_for_fullscreen = False
            self.status.setText(f"STATUS: LIVE — {len(self.layers)} MONITOR(S)")

    def closeEvent(self, event):
        self.stop_wallpaper()
        event.accept()

def main():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    app = QApplication(sys.argv)
    app.setApplicationName("TREDT Webcam Wallpaper")

    window = App()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
