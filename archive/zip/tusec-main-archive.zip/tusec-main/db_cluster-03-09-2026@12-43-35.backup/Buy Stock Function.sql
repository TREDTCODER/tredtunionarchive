create or replace function buy_stock(
  p_symbol text,
  p_quantity numeric,
  p_price numeric
)
returns void
language plpgsql
security definer
as $$
declare
  v_cost numeric;
  v_balance numeric;
begin
  -- total cost
  v_cost := p_quantity * p_price;

  -- lock profile row
  select tc_balance into v_balance
  from profiles
  where id = auth.uid()
  for update;

  if v_balance < v_cost then
    raise exception 'Insufficient TC balance';
  end if;

  -- deduct TC
  update profiles
  set tc_balance = tc_balance - v_cost
  where id = auth.uid();

  -- upsert portfolio
  insert into portfolios (user_id, symbol, quantity, avg_price)
  values (auth.uid(), p_symbol, p_quantity, p_price)
  on conflict (user_id, symbol)
  do update set
    avg_price =
      ((portfolios.quantity * portfolios.avg_price) + (excluded.quantity * excluded.avg_price))
      / (portfolios.quantity + excluded.quantity),
    quantity = portfolios.quantity + excluded.quantity;

  -- log transaction
  insert into transactions (user_id, symbol, side, quantity, price)
  values (auth.uid(), p_symbol, 'BUY', p_quantity, p_price);
end;
$$;
