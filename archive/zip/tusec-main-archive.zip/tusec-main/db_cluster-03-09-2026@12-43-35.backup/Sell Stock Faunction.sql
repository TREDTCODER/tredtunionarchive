create or replace function sell_stock(
  p_symbol text,
  p_quantity numeric,
  p_price numeric
)
returns void
language plpgsql
security definer
as $$
declare
  v_holding numeric;
  v_gain numeric;
begin
  -- lock portfolio row
  select quantity into v_holding
  from portfolios
  where user_id = auth.uid() and symbol = p_symbol
  for update;

  if v_holding is null or v_holding < p_quantity then
    raise exception 'Not enough shares to sell';
  end if;

  v_gain := p_quantity * p_price;

  -- update portfolio
  update portfolios
  set quantity = quantity - p_quantity
  where user_id = auth.uid() and symbol = p_symbol;

  -- delete row if zero
  delete from portfolios
  where user_id = auth.uid() and symbol = p_symbol and quantity = 0;

  -- add TC
  update profiles
  set tc_balance = tc_balance + v_gain
  where id = auth.uid();

  -- log transaction
  insert into transactions (user_id, symbol, side, quantity, price)
  values (auth.uid(), p_symbol, 'SELL', p_quantity, p_price);
end;
$$;
