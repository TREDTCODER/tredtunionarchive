-- ================================
-- 1. CREATE PORTFOLIOS TABLE (IF MISSING)
-- ================================
create table if not exists portfolios (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade,
  symbol text not null,
  quantity numeric not null,
  avg_price numeric not null,
  created_at timestamp default now(),
  unique (user_id, symbol)
);

-- ================================
-- 2. ENABLE RLS
-- ================================
alter table portfolios enable row level security;

-- ================================
-- 3. DROP OLD POLICY (IF ANY)
-- ================================
drop policy if exists "Users manage own portfolio" on portfolios;

-- ================================
-- 4. CREATE POLICY
-- ================================
create policy "Users manage own portfolio"
on portfolios
for all
using (auth.uid() = user_id);
