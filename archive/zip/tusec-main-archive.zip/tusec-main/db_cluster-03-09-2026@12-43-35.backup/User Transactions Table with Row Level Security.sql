create table if not exists transactions (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade,
  symbol text not null,
  side text check (side in ('BUY','SELL')),
  quantity numeric not null,
  price numeric not null,
  created_at timestamp default now()
);

alter table transactions enable row level security;

create policy "Users manage own transactions"
on transactions
for all
using (auth.uid() = user_id);
