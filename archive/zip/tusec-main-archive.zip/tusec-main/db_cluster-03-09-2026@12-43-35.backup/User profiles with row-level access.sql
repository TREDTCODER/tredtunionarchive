create table profiles (
  id uuid references auth.users on delete cascade,
  user_id text unique not null,
  full_name text not null,
  membership text not null,
  tc_balance numeric default 100,
  created_at timestamp default now(),
  primary key (id)
);

alter table profiles enable row level security;

create policy "Users can view own profile"
on profiles for select
using (auth.uid() = id);

create policy "Users can insert own profile"
on profiles for insert
with check (auth.uid() = id);
